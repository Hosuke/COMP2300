#include "client.h"

void control(const InputPacket* inpack, OutputPacket* outpack)
{
	// Put code here
}
